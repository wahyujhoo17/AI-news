import { Pool } from "pg"

const pool = new Pool({
  host: process.env.PGHOST || "localhost",
  port: parseInt(process.env.PGPORT || "5432"),
  database: process.env.PGDATABASE || "ai_news_db",
  user: process.env.PGUSER || "ai_news_user",
  password: process.env.PGPASSWORD || "StrongPass123!",
})

export type Article = {
  id: number
  title: string
  content: string
  source_url: string | null
  source_name: string
  category: string | null
  published_at: string | null
  created_at: string
  is_published: boolean
  ai_model: string | null
  prompt_tokens: number | null
  completion_tokens: number | null
  total_tokens: number | null
  estimated_cost: number | null
}

export type Source = {
  id: number
  name: string
  url: string
  type: string
  is_active: boolean
  created_at: string
}

export async function getRecentArticles(limit: number = 20) {
  const result = await pool.query<Article>(
    `SELECT id, title, content, source_url, source_name, published_at, created_at
     FROM articles 
     WHERE is_published = true 
     ORDER BY published_at DESC, created_at DESC 
     LIMIT $1`,
    [limit]
  )
  return result.rows
}

export async function getAllSources() {
  const result = await pool.query<Source>(
    "SELECT * FROM sources WHERE is_active = true ORDER BY name"
  )
  return result.rows
}

export async function saveArticle(article: Partial<Article>) {
  const result = await pool.query(
    `INSERT INTO articles 
     (title, content, source_url, source_name, category, published_at, is_published, ai_model, prompt_tokens, completion_tokens, total_tokens, estimated_cost) 
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12) 
     RETURNING *`,
    [
      article.title,
      article.content,
      article.source_url,
      article.source_name,
      article.category || null,
      article.published_at,
      article.is_published || false,
      article.ai_model || null,
      article.prompt_tokens || null,
      article.completion_tokens || null,
      article.total_tokens || null,
      article.estimated_cost || null,
    ]
  )
  return result.rows[0]
}

export async function logCrawl(
  sourceId: number | null, 
  status: string, 
  error?: string,
  articlesGenerated?: number
) {
  const result = await pool.query(
    `INSERT INTO crawl_logs (source_id, status, error_message, articles_generated) 
     VALUES ($1, $2, $3, $4) RETURNING *`,
    [sourceId, status, error || null, articlesGenerated || 0]
  )
  return result.rows[0]
}

export default pool
