import cron from "node-cron"
import Parser from "rss-parser"
import fetch from "node-fetch"
import cheerio from "cheerio"
import axios from "axios"
import { pool, logCrawl } from "@/lib/db"

const OPENROUTER_API_KEY = process.env.OPENROUTER_API_KEY
const OPENROUTER_MODEL = process.env.OPENROUTER_MODEL || "openrouter/stepfun/step-3.5-flash:free"

async function fetchRSS(url: string): Promise<any[]> {
  const parser = new Parser()
  try {
    const feed = await parser.parseURL(url)
    return feed.items.map((item) => ({
      title: item.title,
      link: item.link,
      content: item.contentSnippet || item.content || item.summary,
      pubDate: item.pubDate,
      sourceUrl: url,
    }))
  } catch (error) {
    console.error("RSS fetch error:", error)
    return []
  }
}

async function fetchHTML(url: string, selector: string = "article, .post, .news"): Promise<any[]> {
  try {
    const response = await axios.get(url, {
      headers: { "User-Agent": "Mozilla/5.0" },
      timeout: 10000,
    })
    const $ = cheerio.load(response.data)
    const articles = []
    $(selector).each((i, el) => {
      const title = $(el).find("h1, h2, h3, .title").first().text().trim()
      const content = $(el).find("p").slice(0, 3).text().trim().slice(0, 500)
      if (title && content) {
        articles.push({
          title,
          link: url,
          content,
          pubDate: new Date().toISOString(),
          sourceUrl: url,
        })
      }
    })
    return articles.slice(0, 5)
  } catch (error) {
    console.error("HTML fetch error:", error)
    return []
  }
}

async function generateArticle(title: string, sourceContent: string, sourceUrl: string): Promise<{
  title: string
  content: string
  tokens: { prompt: number; completion: number; total: number }
  cost: number
  model: string
}> {
  if (!OPENROUTER_API_KEY) {
    throw new Error("OPENROUTER_API_KEY not set")
  }

  const prompt = `Buatkan artikel berita dalam bahasa Indonesia yang menarik dan informasikan berdasarkan kontribusi di bawah. 
Jangan mention sumber asli. Artikel harus original, dengan paragraf yang rapi.
Judul: ${title}
Konten sumber: ${sourceContent.slice(0, 2000)}

Buatkan artikel lengkap (sekitar 500-800 kata) dengan intro, isi, dan kesimpulan.`

  const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${OPENROUTER_API_KEY}`,
      "Content-Type": "application/json",
      "HTTP-Referer": "https://lumicloud.my.id",
      "X-Title": "AI News Worker",
    },
    body: JSON.stringify({
      model: OPENROUTER_MODEL,
      messages: [
        { role: "system", content: "Kamu adalah jurnalis profesional bahasa Indonesia." },
        { role: "user", content: prompt },
      ],
      temperature: 0.7,
      max_tokens: 1000,
    }),
  })

  if (!response.ok) {
    const err = await response.text()
    throw new Error(`OpenRouter error: ${response.status} - ${err}`)
  }

  const data = await response.json()
  const content = data.choices[0].message.content
  const usage = data.usage

  return {
    title,
    content,
    tokens: {
      prompt: usage.prompt_tokens,
      completion: usage.completion_tokens,
      total: usage.total_tokens,
    },
    cost: usage.total_tokens * 0.000001, // approximate
    model: OPENROUTER_MODEL,
  }
}

async function processSource(source: any) {
  console.log(`Processing source: ${source.name}`)
  let articles = []
  if (source.type === "rss") {
    articles = await fetchRSS(source.url)
  } else {
    articles = await fetchHTML(source.url)
  }

  const now = new Date().toISOString()
  await logCrawl(source.id, "started")

  let generatedCount = 0
  for (const article of articles.slice(0, 3)) {
    try {
      const generated = await generateArticle(article.title, article.content, article.link)
      await pool.query(
        `INSERT INTO articles 
         (title, content, source_url, source_name, published_at, is_published, ai_model, prompt_tokens, completion_tokens, total_tokens, estimated_cost)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
        [
          generated.title,
          generated.content,
          article.link,
          source.name,
          now,
          true,
          generated.model,
          generated.tokens.prompt,
          generated.tokens.completion,
          generated.tokens.total,
          generated.cost,
        ]
      )
      generatedCount++
      console.log(`Generated article: ${generated.title}`)
    } catch (err) {
      console.error(`Failed to generate article from ${article.title}:`, err.message)
    }
  }

  await logCrawl(source.id, "completed", undefined, generatedCount)
  console.log(`Source ${source.name} done. Generated: ${generatedCount}`)
}

async function runCrawl() {
  console.log("Starting crawl job...")
  try {
    const result = await pool.query("SELECT * FROM sources WHERE is_active = true")
    const sources = result.rows

    for (const source of sources) {
      try {
        await processSource(source)
      } catch (err) {
        console.error(`Crawl failed for source ${source.name}:`, err.message)
        await logCrawl(source.id, "error", err.message)
      }
    }
    console.log("Crawl job completed.")
  } catch (error) {
    console.error("Crawl job fatal error:", error)
  }
}

// Schedule every 1 minute
cron.schedule("* * * * *", async () => {
  console.log("Running scheduled crawl...")
  await runCrawl()
})

console.log("AI News Worker started. Will run every minute.")
if (require.main === module) {
  runCrawl().catch(console.error)
}
